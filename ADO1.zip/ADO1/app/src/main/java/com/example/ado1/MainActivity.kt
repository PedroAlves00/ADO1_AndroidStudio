package com.example.ado1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var Custo = txtPreçoCusto.text.toString()
        var Venda = txtPreçoVenda.text.toString()
        var Nome = txtNomeProduto.text.toString()
        val sh = getSharedPreferences("CalculoPrejuVal", Context.MODE_PRIVATE)
        //CALCULA O VALOR E O CUSTO
        btCalcular.setOnClickListener { v: View? ->

            if (Custo.isNotEmpty() && Venda.isNotEmpty() && Nome.isNotEmpty()) {
                var calculo = Custo.toDouble() - Venda.toDouble()
                if (Custo > Venda) {
                    Toast.makeText(this,"Esse produto fornece Lucro de "+calculo+"!",Toast.LENGTH_SHORT).show()
                } else if (Custo < Venda) {
                    Toast.makeText(this,"Esse produto fornece Prejuízo de "+calculo+"!",Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this,"Ambos os valores iguais!",Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Todos os campos precisam ser preenchidos", Toast.LENGTH_SHORT).show()
            }
        }
        //CADASTRA OS PRODUTOS
        //PROFESSOR NÃO CONSEGUI APLICAR O METODO QUE O SENHOR SUGERIU E COMO EU MENCIONEI ANTES, TAMBEM NÃO CONSEGUE COMPILAR E TESTAR O APLICATIVO ENTÃO OPTEI POR TENTAR NA LOGICA
        btCadastrar.setOnClickListener { v: View? ->

            if(Nome.isNotEmpty()){
//                sh.edit().putString().apply()
                //Professor tentei utilizar esse metodo para verificar se era possivel salvar os tres campos dessa maneira. Mas não encontrei muitas soluções na internet portanto fiz dessa maneira.
                //Caso esteja incorreta, poderia me mostrar onde esta o erro?
                sh.edit().apply(){
                    putString("Nome",Nome)
                    putString("ValCusto",Custo)
                    putString("ValVenda",Venda)
                }.apply()
                Toast.makeText(this,"Produto: "+Nome+", Salvo Com Sucesso!",Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this,"Nome/Produto Inexistente! Cadastre esse produto",Toast.LENGTH_SHORT).show()
            }
        }
        //FAZ AS CONSULTAS DE PRODUTOS
        btConsultar.setOnClickListener { v: View? ->
            if(txtNomeProduto.text.isNotEmpty()){
                var PegarNome = sh.getString(Nome,"")
                if(Custo.isNullOrEmpty() && Venda.isNullOrEmpty() && Nome.isNullOrEmpty()){
                    Toast.makeText(this,"Produto Inexistente",Toast.LENGTH_SHORT).show()
                }
                else{
                    txtNomeProduto.setText(PegarNome)
                    Toast.makeText(this,"Produto: "+Nome+", Carregado Com Sucesso!",Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this,"Produto Inexistente",Toast.LENGTH_SHORT).show()
            }

        }
    }
}


